#!/bin/bash
while :
do
    python one_click_deploy.py
    echo "*****************************************"
    sleep 5
done