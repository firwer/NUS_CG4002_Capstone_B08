1) This is the interface to Eval server
2) Open "index.html" to interface with the Eval server