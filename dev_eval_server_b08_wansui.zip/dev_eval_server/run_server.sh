#!/bin/bash
while :
do
    python3 WebSocketServer.py
    echo "*****************************************"
    sleep 5
done